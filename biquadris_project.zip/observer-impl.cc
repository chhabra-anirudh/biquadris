module Observer;

using namespace std;

Observer::~Observer() {}
